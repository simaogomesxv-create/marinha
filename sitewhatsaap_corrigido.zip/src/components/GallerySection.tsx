import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef, useState } from "react";
import img1 from "@/assets/IMG-20260416-WA0001.jpg";
import img2 from "@/assets/IMG-20260416-WA0002.jpg";
import img3 from "@/assets/IMG-20260416-WA0003.jpg";
import img4 from "@/assets/IMG-20260416-WA0004.jpg";
import img6 from "@/assets/IMG-20260416-WA0006.jpg";
import img7 from "@/assets/IMG-20260416-WA0007.jpg";
import img8 from "@/assets/IMG-20260416-WA0008.jpg";
import img9 from "@/assets/IMG-20260416-WA0009.jpg";
import img10 from "@/assets/IMG-20260416-WA0010.jpg";

const images = [
  { src: img1, title: "Mergulhadores em Ação", tag: "Mergulho Comercial" },
  { src: img2, title: "Equipa Pronta a Operar", tag: "Operações" },
  { src: img3, title: "Suporte de Superfície", tag: "Suporte Vital" },
  { src: img4, title: "Logística Portuária", tag: "Logística" },
  { src: img7, title: "Preparação do Mergulhador", tag: "Mergulho Comercial" },
  { src: img6, title: "Compressor de Mergulho", tag: "Equipamento" },
  { src: img8, title: "Inspeção Subaquática", tag: "Inspeção" },
  { src: img9, title: "Estrutura de Apoio", tag: "Infraestrutura" },
  { src: img10, title: "Transporte Especializado", tag: "Transporte" },
];

function GalleryCard({ item, index }: { item: typeof images[0]; index: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  const [hovered, setHovered] = useState(false);

  // Staggered animation based on position
  const getDelay = () => {
    if (index === 0) return 0;
    if (index <= 2) return 0.15;
    return 0.3;
  };

  // Rotation animation for floating effect
  const rotationVariants = {
    hidden: { opacity: 0, scale: 0.7, rotateZ: -10 },
    visible: {
      opacity: 1,
      scale: 1,
      rotateZ: 0,
      transition: {
        delay: getDelay(),
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1],
      },
    },
  };

  return (
    <motion.div
      ref={ref}
      className={`relative overflow-hidden rounded-2xl cursor-pointer group ${
        index === 0 ? "md:col-span-2 md:row-span-2" : ""
      }`}
      variants={rotationVariants}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      style={{ perspective: "1000px" }}
      whileHover={{ y: -12, transition: { duration: 0.4 } }}
    >
      {/* Animated background with parallax */}
      <motion.div
        className="absolute inset-0"
        animate={{ scale: hovered ? 1.15 : 1 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
      >
        <img
          src={item.src}
          alt={item.title}
          className="w-full h-full object-cover"
          loading="lazy"
          width={1024}
          height={768}
        />
      </motion.div>

      {/* Animated gradient overlay with multiple layers */}
      <motion.div
        className="absolute inset-0"
        animate={{
          background: hovered
            ? "linear-gradient(135deg, oklch(0.65 0.2 200 / 40%), oklch(0.72 0.15 70 / 30%), oklch(0.5 0.1 250 / 20%))"
            : "linear-gradient(180deg, transparent 30%, oklch(0.1 0.04 245 / 85%))",
        }}
        transition={{ duration: 0.5 }}
      />

      {/* Animated shimmer effect on hover */}
      {hovered && (
        <>
          {/* Prismatic light effect */}
          <motion.div
            className="absolute inset-0 mix-blend-screen"
            style={{
              background:
                "linear-gradient(45deg, oklch(0.8 0.2 200 / 20%), transparent 50%, oklch(0.7 0.15 70 / 15%))",
            }}
            initial={{ x: -200, opacity: 0 }}
            animate={{ x: 200, opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeInOut" }}
          />

          {/* Pulsing glow effect */}
          <motion.div
            className="absolute inset-0 mix-blend-overlay"
            style={{
              background:
                "radial-gradient(circle at 50% 50%, oklch(0.85 0.2 200 / 30%), transparent 60%)",
            }}
            animate={{ scale: [1, 1.3, 1], opacity: [0.4, 0.8, 0.4] }}
            transition={{ duration: 2.5, repeat: Infinity }}
          />

          {/* Corner accent lights */}
          <motion.div
            className="absolute top-0 right-0 w-32 h-32"
            style={{
              background:
                "radial-gradient(circle, oklch(0.75 0.2 200 / 25%), transparent 70%)",
            }}
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 3, repeat: Infinity }}
          />
          <motion.div
            className="absolute bottom-0 left-0 w-32 h-32"
            style={{
              background:
                "radial-gradient(circle, oklch(0.7 0.15 70 / 20%), transparent 70%)",
            }}
            animate={{ scale: [1.2, 1, 1.2] }}
            transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
          />
        </>
      )}

      {/* Floating particles on hover */}
      {hovered &&
        Array.from({ length: 8 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: Math.random() * 4 + 2,
              height: Math.random() * 4 + 2,
              background: `oklch(0.75 0.15 ${200 + Math.random() * 60} / 0.6)`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{
              opacity: [0, 0.8, 0],
              scale: [0, 1, 0],
              y: [0, -40, -80],
              x: [0, Math.random() * 40 - 20, Math.random() * 40 - 20],
            }}
            transition={{
              duration: 2 + Math.random() * 1,
              delay: Math.random() * 0.3,
              repeat: Infinity,
              repeatDelay: Math.random() * 2,
            }}
          />
        ))}

      {/* Content container */}
      <div className="absolute bottom-0 left-0 right-0 p-6 z-10">
        {/* Tag with animation */}
        <motion.span
          className="inline-block px-4 py-2 rounded-full text-xs font-medium tracking-wider uppercase mb-3"
          style={{
            background: "oklch(0.65 0.2 200 / 35%)",
            color: "oklch(0.9 0.12 200)",
            backdropFilter: "blur(8px)",
          }}
          animate={hovered ? { y: 0, opacity: 1, scale: 1 } : { y: 10, opacity: 0.6, scale: 0.95 }}
          transition={{ duration: 0.4 }}
        >
          {item.tag}
        </motion.span>

        {/* Title with staggered animation */}
        <motion.div
          animate={hovered ? { y: 0 } : { y: 8 }}
          transition={{ duration: 0.4 }}
        >
          <h3 className="text-xl md:text-2xl font-bold font-heading text-foreground leading-tight">
            {item.title}
          </h3>
        </motion.div>

        {/* Animated underline on hover */}
        {hovered && (
          <motion.div
            className="h-1 bg-gradient-to-r from-cyan-accent via-blue-400 to-transparent rounded-full mt-2"
            initial={{ width: 0 }}
            animate={{ width: "60px" }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          />
        )}
      </div>

      {/* Border glow effect on hover */}
      {hovered && (
        <motion.div
          className="absolute inset-0 rounded-2xl pointer-events-none"
          style={{
            border: "2px solid",
            borderImage: "linear-gradient(135deg, oklch(0.75 0.2 200 / 50%), oklch(0.72 0.15 70 / 30%), transparent) 1",
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        />
      )}
    </motion.div>
  );
}

export default function GallerySection() {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [50, -50]);

  return (
    <section id="gallery" className="relative py-32 px-6 overflow-hidden" ref={containerRef}>
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-0 left-1/4 w-96 h-96 rounded-full"
          style={{
            background:
              "radial-gradient(circle, oklch(0.65 0.2 200 / 8%), transparent 70%)",
          }}
          animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full"
          style={{
            background:
              "radial-gradient(circle, oklch(0.72 0.15 70 / 8%), transparent 70%)",
          }}
          animate={{ scale: [1.2, 1, 1.2], opacity: [0.5, 0.8, 0.5] }}
          transition={{ duration: 8, repeat: Infinity, delay: 1 }}
        />
      </div>

      <div className="absolute inset-0 bg-secondary/20" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section header with animation */}
        <motion.div className="text-center mb-16" style={{ y }}>
          <motion.p
            className="text-sm tracking-[0.3em] uppercase text-cyan-accent mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            Galeria
          </motion.p>
          <motion.h2
            className="text-3xl md:text-5xl font-bold font-heading"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
          >
            A Nossa <span className="text-gradient-brass">Equipa em Ação</span>
          </motion.h2>
          <motion.p
            className="mt-4 text-muted-foreground max-w-xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Imagens que captam a essência do nosso trabalho nas profundezas do oceano
          </motion.p>
        </motion.div>

        {/* Gallery grid with creative layout */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6 auto-rows-[200px] md:auto-rows-[280px]">
          {images.map((item, i) => (
            <GalleryCard key={item.src} item={item} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
