import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const stats = [
  { value: "2024", label: "Ano de Fundação" },
  { value: "IMCA", label: "Certificação ADS" },
  { value: "24h", label: "Operação Contínua" },
  { value: "100%", label: "Foco em Segurança" },
];

export default function AboutSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="relative py-32 px-6 overflow-hidden" ref={ref}>
      <div className="absolute inset-0 bg-secondary/50" />

      <div className="relative z-10 max-w-7xl mx-auto">
        <motion.div
          className="grid lg:grid-cols-2 gap-16 items-center"
          initial={{ opacity: 0, y: 60 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <div>
            <p className="text-sm tracking-[0.3em] uppercase text-cyan-accent mb-4">Sobre Nós</p>
            <h2 className="text-3xl md:text-5xl font-bold font-heading text-foreground leading-tight">
              Pioneiros em{" "}
              <span className="text-gradient-brass">Tecnologia Naval</span>
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed text-lg">
              A Tecnologia Navais - Soluções subaquáticas e marítimas é especializada em serviços de mergulho profissional para o setor marítimo. Com base em Luanda, Angola, atuamos com limpeza e inspeção de cascos de navios e apoio em obras marítimas, garantindo agilidade, segurança e conformidade ambiental.
            </p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Somos parceiros estratégicos para manter a sua embarcação eficiente e a sua obra segura. Nossa equipe é certificada IMCA/ADS, composta por mergulhadores comerciais qualificados prontos para atender nos principais portos de Angola, com operação 24h em navios fundeados ou atracados.
            </p>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                className="glass rounded-xl p-6 text-center glow-cyan"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 0.2 + i * 0.15, duration: 0.6, ease: "easeOut" }}
              >
                <div className="text-3xl md:text-4xl font-black text-gradient-brass font-heading">
                  {stat.value}
                </div>
                <div className="mt-2 text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
