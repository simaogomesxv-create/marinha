import { createFileRoute } from "@tanstack/react-router";
import { useState, useCallback } from "react";
import LoadingAnimation from "@/components/LoadingAnimation";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ServicesSection from "@/components/ServicesSection";
import GallerySection from "@/components/GallerySection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
      meta: [
      { title: "Tecnologia Navais — Mergulho Profissional e Soluções Marítimas em Angola" },
      { name: "description", content: "Especialistas em limpeza de cascos, inspeção submarina e mergulho comercial em Luanda e principais portos de Angola. Atendimento 24h com certificação IMCA/ADS." },
      { property: "og:title", content: "Tecnologia Navais — Mergulho Profissional em Angola" },
      { property: "og:description", content: "Limpeza de cascos, inspeção de obras vivas e manutenção marítima com equipe certificada IMCA/ADS." },
    ],
  }),
  component: Index,
});

function Index() {
  const [loaded, setLoaded] = useState(false);
  const handleComplete = useCallback(() => setLoaded(true), []);

  return (
    <>
      {!loaded && <LoadingAnimation onComplete={handleComplete} />}
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <GallerySection />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}
