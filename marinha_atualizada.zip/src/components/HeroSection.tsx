import { motion } from "framer-motion";
import oceanBg from "@/assets/ocean-bg.jpg";

export default function HeroSection() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img src={oceanBg} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, oklch(0.1 0.04 245 / 70%), oklch(0.12 0.04 245 / 90%))" }} />
      </div>

      {/* Animated bubbles */}
      {Array.from({ length: 12 }).map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full animate-bubble"
          style={{
            width: Math.random() * 8 + 4,
            height: Math.random() * 8 + 4,
            background: `oklch(0.75 0.15 200 / ${Math.random() * 0.3 + 0.05})`,
            left: `${Math.random() * 100}%`,
            "--duration": `${Math.random() * 6 + 5}s`,
            "--delay": `${Math.random() * 5}s`,
          } as React.CSSProperties}
        />
      ))}

      <div className="relative z-10 text-center px-6 max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 4.5, duration: 1, ease: "easeOut" }}
        >
          <p className="text-sm md:text-base tracking-[0.4em] uppercase text-cyan-accent mb-6">
            Excelência nas Profundezas
          </p>
        </motion.div>

        <motion.h1
          className="text-4xl md:text-7xl lg:text-8xl font-black leading-tight font-heading"
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 4.8, duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="text-gradient-brass">Soluções</span>
          <br />
          <span className="text-foreground">Subaquáticas &</span>
          <br />
          <span className="text-gradient-cyan">Marítimas</span>
        </motion.h1>

        <motion.p
          className="mt-8 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 5.2, duration: 1 }}
        >
          Líderes em tecnologia naval, oferecemos serviços especializados de mergulho comercial,
          inspeção submarina e manutenção de infraestruturas marítimas.
        </motion.p>

        <motion.div
          className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 5.6, duration: 0.8 }}
        >
          <a
            href="#services"
            className="px-8 py-4 rounded-lg font-semibold text-sm tracking-wider uppercase bg-primary text-primary-foreground glow-brass hover:scale-105 transition-transform duration-300"
          >
            Nossos Serviços
          </a>
          <a
            href="#contact"
            className="px-8 py-4 rounded-lg font-semibold text-sm tracking-wider uppercase border border-cyan-accent text-cyan-accent hover:bg-cyan-accent/10 transition-all duration-300"
          >
            Fale Connosco
          </a>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 rounded-full border-2 border-foreground/30 flex items-start justify-center pt-2">
          <div className="w-1 h-2 rounded-full bg-cyan-accent" />
        </div>
      </motion.div>
    </section>
  );
}
