import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import logo from "@/assets/logo.jpg";

// Professional SVG Icons
const AnchorIcon = () => (
  <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 2v10M12 12a3 3 0 1 0 0 6 3 3 0 0 0 0-6M12 18v4M8 22h8M5 12l-2 4h2M19 12l2 4h-2" />
  </svg>
);

const WaveIcon = () => (
  <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M2 12c1.5-2 3-3 5-3s3.5 1 5 3c1.5 2 3 3 5 3s3.5-1 5-3M2 18c1.5-2 3-3 5-3s3.5 1 5 3c1.5 2 3 3 5 3s3.5-1 5-3" />
  </svg>
);

const CompassIcon = () => (
  <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="10" />
    <path d="M12 2v10M12 12l7 7M12 12l-7 7M12 12l7-7M12 12l-7-7" />
  </svg>
);

export default function LoadingAnimation({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 500);
    const t2 = setTimeout(() => setPhase(2), 2000);
    const t3 = setTimeout(() => setPhase(3), 3200);
    const t4 = setTimeout(() => onComplete(), 4200);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, [onComplete]);

  return (
    <AnimatePresence>
      {phase < 3 && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-center justify-center"
          style={{ background: "linear-gradient(180deg, oklch(0.12 0.04 245), oklch(0.08 0.03 250))" }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        >
          {/* Underwater particles */}
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full"
              style={{
                width: Math.random() * 6 + 2,
                height: Math.random() * 6 + 2,
                background: `oklch(0.75 0.15 200 / ${Math.random() * 0.4 + 0.1})`,
                left: `${Math.random() * 100}%`,
              }}
              initial={{ y: "100vh", opacity: 0 }}
              animate={{ y: "-10vh", opacity: [0, 0.6, 0] }}
              transition={{
                duration: Math.random() * 4 + 3,
                delay: Math.random() * 2,
                repeat: Infinity,
                ease: "linear",
              }}
            />
          ))}

          {/* Floating icons around logo */}
          <motion.div
            className="absolute text-cyan-accent"
            initial={{ opacity: 0, scale: 0 }}
            animate={phase >= 1 ? { opacity: 0.6, scale: 1 } : {}}
            transition={{ delay: 0.5, duration: 0.8 }}
            style={{ top: "20%", left: "15%" }}
          >
            <motion.div
              animate={{ y: [0, -10, 0], rotate: [0, 5, 0] }}
              transition={{ duration: 4, repeat: Infinity }}
            >
              <AnchorIcon />
            </motion.div>
          </motion.div>

          <motion.div
            className="absolute text-blue-400"
            initial={{ opacity: 0, scale: 0 }}
            animate={phase >= 1 ? { opacity: 0.6, scale: 1 } : {}}
            transition={{ delay: 0.7, duration: 0.8 }}
            style={{ top: "25%", right: "12%" }}
          >
            <motion.div
              animate={{ y: [0, 15, 0], rotate: [0, -5, 0] }}
              transition={{ duration: 5, repeat: Infinity }}
            >
              <WaveIcon />
            </motion.div>
          </motion.div>

          <motion.div
            className="absolute text-cyan-300"
            initial={{ opacity: 0, scale: 0 }}
            animate={phase >= 1 ? { opacity: 0.6, scale: 1 } : {}}
            transition={{ delay: 0.9, duration: 0.8 }}
            style={{ bottom: "20%", left: "10%" }}
          >
            <motion.div
              animate={{ y: [0, 10, 0], rotate: [0, -8, 0] }}
              transition={{ duration: 4.5, repeat: Infinity }}
            >
              <CompassIcon />
            </motion.div>
          </motion.div>

          {/* Logo with 3D perspective animation - Centered */}
          <div style={{ perspective: "1200px" }}>
            <motion.div
              initial={{ rotateY: -180, rotateX: 25, scale: 0.3, opacity: 0 }}
              animate={
                phase >= 1
                  ? { rotateY: 0, rotateX: 0, scale: 1, opacity: 1 }
                  : { rotateY: -180, rotateX: 25, scale: 0.3, opacity: 0 }
              }
              transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformStyle: "preserve-3d" }}
            >
              <motion.div
                animate={phase >= 1 ? {
                  boxShadow: [
                    "0 0 0px oklch(0.65 0.2 200 / 0%)",
                    "0 0 80px oklch(0.65 0.2 200 / 40%)",
                    "0 0 40px oklch(0.65 0.2 200 / 20%)",
                  ],
                } : {}}
                transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
                className="rounded-full"
              >
                <img
                  src={logo}
                  alt="Tecnologia Navais"
                  className="w-40 h-40 md:w-56 md:h-56 rounded-full object-cover"
                  style={{ filter: "drop-shadow(0 0 30px oklch(0.72 0.15 70 / 40%))" }}
                />
              </motion.div>
            </motion.div>
          </div>

          {/* Company name reveal - Positioned below logo */}
          <motion.div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 translate-y-40 text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={phase >= 2 ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="text-3xl md:text-5xl font-bold tracking-wider text-gradient-brass font-heading">
              TECNOLOGIA NAVAIS
            </h1>
            <motion.p
              className="mt-3 text-sm md:text-base tracking-[0.3em] uppercase text-gradient-cyan"
              initial={{ opacity: 0 }}
              animate={phase >= 2 ? { opacity: 1 } : {}}
              transition={{ delay: 0.4, duration: 0.6 }}
            >
              Soluções Subaquáticas e Marítimas
            </motion.p>
          </motion.div>

          {/* Scanning line */}
          <motion.div
            className="absolute left-0 right-0 h-px"
            style={{ background: "linear-gradient(90deg, transparent, oklch(0.75 0.15 200 / 60%), transparent)" }}
            initial={{ top: "0%" }}
            animate={{ top: "100%" }}
            transition={{ duration: 3, ease: "linear", repeat: Infinity }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
