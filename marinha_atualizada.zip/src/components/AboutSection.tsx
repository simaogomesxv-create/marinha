import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const stats = [
  { value: "25+", label: "Anos de Experiência" },
  { value: "500+", label: "Projectos Concluídos" },
  { value: "150+", label: "Profissionais" },
  { value: "98%", label: "Satisfação do Cliente" },
];

export default function AboutSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="relative py-32 px-6 overflow-hidden" ref={ref}>
      <div className="absolute inset-0 bg-secondary/50" />

      <div className="relative z-10 max-w-7xl mx-auto">
        <motion.div
          className="grid lg:grid-cols-2 gap-16 items-center"
          initial={{ opacity: 0, y: 60 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <div>
            <p className="text-sm tracking-[0.3em] uppercase text-cyan-accent mb-4">Sobre Nós</p>
            <h2 className="text-3xl md:text-5xl font-bold font-heading text-foreground leading-tight">
              Pioneiros em{" "}
              <span className="text-gradient-brass">Tecnologia Naval</span>
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed text-lg">
              A Tecnologia Navais é uma empresa líder em soluções subaquáticas e marítimas,
              com mais de duas décadas de experiência em mergulho comercial, inspeção de
              infraestruturas e manutenção naval. A nossa equipa de profissionais altamente
              qualificados opera com os mais elevados padrões de segurança e qualidade.
            </p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Desde operações de salvamento a inspeções com ROV, oferecemos soluções completas
              para o sector naval e offshore, utilizando tecnologia de ponta e métodos
              comprovados que garantem resultados excepcionais.
            </p>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                className="glass rounded-xl p-6 text-center glow-cyan"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 0.2 + i * 0.15, duration: 0.6, ease: "easeOut" }}
              >
                <div className="text-3xl md:text-4xl font-black text-gradient-brass font-heading">
                  {stat.value}
                </div>
                <div className="mt-2 text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
