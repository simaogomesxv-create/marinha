import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";

export default function ContactSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [submitted, setSubmitted] = useState(false);

  return (
    <section id="contact" className="relative py-32 px-6" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <p className="text-sm tracking-[0.3em] uppercase text-cyan-accent mb-4">Contacto</p>
          <h2 className="text-3xl md:text-5xl font-bold font-heading">
            Entre em <span className="text-gradient-brass">Contacto</span>
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Info */}
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            <div>
              <h3 className="text-xl font-bold font-heading text-foreground mb-4">
                Pronto para o seu próximo projecto?
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                A nossa equipa está preparada para responder a qualquer desafio subaquático
                ou marítimo. Contacte-nos para uma consulta gratuita.
              </p>
            </div>

            {[
              { icon: "📍", label: "Localização", value: "Porto, Portugal" },
              { icon: "📞", label: "Telefone", value: "+351 222 000 000" },
              { icon: "✉️", label: "Email", value: "info@tecnologianavais.pt" },
              { icon: "🕐", label: "Horário", value: "Seg-Sex: 08:00 - 18:00" },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                className="flex items-start gap-4"
                initial={{ opacity: 0, x: -20 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ delay: 0.3 + i * 0.1, duration: 0.5 }}
              >
                <span className="text-2xl">{item.icon}</span>
                <div>
                  <div className="text-sm text-muted-foreground">{item.label}</div>
                  <div className="font-medium text-foreground">{item.value}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Form */}
          <motion.form
            className="glass rounded-2xl p-8 space-y-6"
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.4, duration: 0.8 }}
            onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}
          >
            {submitted ? (
              <div className="text-center py-12">
                <div className="text-5xl mb-4">✅</div>
                <h3 className="text-xl font-bold font-heading text-foreground">Mensagem Enviada!</h3>
                <p className="text-muted-foreground mt-2">Entraremos em contacto brevemente.</p>
              </div>
            ) : (
              <>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Nome</label>
                    <input
                      type="text"
                      required
                      className="w-full px-4 py-3 rounded-lg bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all"
                      placeholder="Seu nome"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Email</label>
                    <input
                      type="email"
                      required
                      className="w-full px-4 py-3 rounded-lg bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all"
                      placeholder="email@exemplo.pt"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Assunto</label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-3 rounded-lg bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all"
                    placeholder="Assunto da mensagem"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Mensagem</label>
                  <textarea
                    rows={5}
                    required
                    className="w-full px-4 py-3 rounded-lg bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all resize-none"
                    placeholder="Descreva o seu projecto..."
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-4 rounded-lg font-semibold text-sm tracking-wider uppercase bg-primary text-primary-foreground glow-brass hover:scale-[1.02] transition-transform duration-300"
                >
                  Enviar Mensagem
                </button>
              </>
            )}
          </motion.form>
        </div>
      </div>
    </section>
  );
}
