import { motion, useInView } from "framer-motion";
import { useRef } from "react";

// Professional SVG Icons
const DivingIcon = () => (
  <svg className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <circle cx="12" cy="6" r="2" />
    <path d="M10 9h4v2h-1v6h-2v-6h-1V9Z" />
    <path d="M8 15c-1 1-2 2-3 3M16 15c1 1 2 2 3 3" />
    <path d="M10 18l-2 3M14 18l2 3" />
  </svg>
);

const WrenchIcon = () => (
  <svg className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 1 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
  </svg>
);

const DroneIcon = () => (
  <svg className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <circle cx="12" cy="12" r="3" />
    <path d="M12 2v4M12 18v4M2 12h4M18 12h4" />
    <path d="M5.64 5.64l2.83 2.83M15.53 15.53l2.83 2.83M5.64 18.36l2.83-2.83M15.53 8.47l2.83-2.83" />
  </svg>
);

const AnchorIcon = () => (
  <svg className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <circle cx="12" cy="13" r="2" />
    <path d="M12 2v9M12 15v7M8 22h8M5 15l-3 3h2M19 15l3 3h-2" />
  </svg>
);

const PipelineIcon = () => (
  <svg className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <rect x="2" y="8" width="4" height="8" rx="1" />
    <rect x="9" y="4" width="4" height="12" rx="1" />
    <rect x="16" y="8" width="4" height="8" rx="1" />
    <path d="M6 12h3M13 10h3M20 12h2" />
  </svg>
);

const ShieldIcon = () => (
  <svg className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M12 2L4 6v6c0 6 8 10 8 10s8-4 8-10V6l-8-4Z" />
    <path d="M12 10v4M10 12h4" />
  </svg>
);

const services = [
  {
    icon: DivingIcon,
    title: "Mergulho Comercial",
    desc: "Operações de mergulho profissional para inspeção, manutenção e reparação de estruturas subaquáticas.",
  },
  {
    icon: WrenchIcon,
    title: "Manutenção Naval",
    desc: "Serviços especializados de manutenção e reparação de embarcações e plataformas offshore.",
  },
  {
    icon: DroneIcon,
    title: "Inspeção com ROV",
    desc: "Utilização de veículos operados remotamente para inspeções subaquáticas de alta precisão.",
  },
  {
    icon: AnchorIcon,
    title: "Operações de Salvamento",
    desc: "Resgate e recuperação de embarcações, cargas e estruturas submersas.",
  },
  {
    icon: PipelineIcon,
    title: "Inspeção de Pipelines",
    desc: "Monitorização e inspeção de oleodutos e gasodutos submarinos com tecnologia avançada.",
  },
  {
    icon: ShieldIcon,
    title: "Proteção Catódica",
    desc: "Instalação e manutenção de sistemas de proteção catódica para infraestruturas marítimas.",
  },
];

export default function ServicesSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="services" className="relative py-32 px-6" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <p className="text-sm tracking-[0.3em] uppercase text-cyan-accent mb-4">Serviços</p>
          <h2 className="text-3xl md:text-5xl font-bold font-heading">
            O Que <span className="text-gradient-brass">Oferecemos</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => {
            const IconComponent = s.icon;
            return (
              <motion.div
                key={s.title}
                className="glass rounded-xl p-8 group hover:glow-cyan transition-all duration-500 cursor-default"
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.1 * i, duration: 0.6 }}
                whileHover={{ y: -8, transition: { duration: 0.3 } }}
              >
                <motion.div
                  className="text-cyan-accent mb-4 inline-flex p-3 rounded-lg bg-cyan-accent/10"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                >
                  <IconComponent />
                </motion.div>
                <h3 className="text-xl font-bold font-heading text-foreground mb-3">{s.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{s.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
