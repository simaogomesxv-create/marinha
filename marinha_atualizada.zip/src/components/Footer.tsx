import logo from "@/assets/logo.jpg";

export default function Footer() {
  return (
    <footer className="border-t border-border py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <img src={logo} alt="Logo" className="w-8 h-8 rounded-full" />
          <span className="text-sm font-bold tracking-wider text-gradient-brass font-heading">
            TECNOLOGIA NAVAIS
          </span>
        </div>
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} Tecnologia Navais. Todos os direitos reservados.
        </p>
        <div className="flex gap-6">
          {["Facebook", "LinkedIn", "Instagram"].map((s) => (
            <a key={s} href="#" className="text-sm text-muted-foreground hover:text-cyan-accent transition-colors">
              {s}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
}
