import { createFileRoute } from "@tanstack/react-router";
import { useState, useCallback } from "react";
import LoadingAnimation from "@/components/LoadingAnimation";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ServicesSection from "@/components/ServicesSection";
import GallerySection from "@/components/GallerySection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Tecnologia Navais — Soluções Subaquáticas e Marítimas" },
      { name: "description", content: "Líderes em tecnologia naval, mergulho comercial, inspeção submarina e manutenção de infraestruturas marítimas." },
      { property: "og:title", content: "Tecnologia Navais — Soluções Subaquáticas e Marítimas" },
      { property: "og:description", content: "Soluções especializadas em mergulho comercial, ROV, salvamento e manutenção naval." },
    ],
  }),
  component: Index,
});

function Index() {
  const [loaded, setLoaded] = useState(false);
  const handleComplete = useCallback(() => setLoaded(true), []);

  return (
    <>
      {!loaded && <LoadingAnimation onComplete={handleComplete} />}
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <GallerySection />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}
